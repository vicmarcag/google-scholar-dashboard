import{_ as p}from"./preload-helper-6Yt1Wogo.js";import{o as h,d as u,h as v,r as f}from"./storage-B94auzpR.js";(typeof chrome>"u"||!chrome.storage)&&await p(()=>import("./chrome-storage-shim-58SULCr6.js"),[]);const i=50,c=document.getElementById("cards"),g=document.getElementById("empty-state"),l=document.getElementById("warning-banner"),$=document.getElementById("refresh-all-btn"),d=document.getElementById("sort-select"),E={ok:"Updated",pending:"Updating…",blocked:"Google has temporarily blocked requests",error:"Error updating"};function b(e){return`https://scholar.google.com/citations?user=${e}&hl=en`}function y(e){return e?new Date(e).toLocaleString("en-US",{dateStyle:"medium",timeStyle:"short"}):"—"}const x=90;function k(e){if(!e||e.length===0)return'<div class="sparkline sparkline-empty">No yearly citation data</div>';const t=e.slice(-10),s=Math.max(...t.map(n=>n.count),1);return`<div class="sparkline">${t.map(n=>`<div class="spark-bar-wrap" title="${n.year}: ${n.count} citations">
          <span class="spark-count">${n.count}</span>
          <div class="spark-bar" style="height:${Math.max(n.count/s*x,3)}px"></div>
          <span class="spark-year">${String(n.year).slice(2)}</span>
        </div>`).join("")}</div>`}const A={default:null,"hindex-desc":(e,t)=>(t.hIndex??-1)-(e.hIndex??-1),"hindex-asc":(e,t)=>(e.hIndex??-1)-(t.hIndex??-1),"name-asc":(e,t)=>e.name.localeCompare(t.name),"name-desc":(e,t)=>t.name.localeCompare(e.name)};function S(e,t,s){const a=A[s];return a?[...e].sort((n,r)=>a({name:(t[n.id]?.data?.name??n.id).toLowerCase(),hIndex:t[n.id]?.data?.hIndex},{name:(t[r.id]?.data?.name??r.id).toLowerCase(),hIndex:t[r.id]?.data?.hIndex})):e}function _(e,t){const s=t?.status??"pending",a=t?.data,n=document.createElement("article");n.className=`card card-${s}`,n.dataset.authorId=e;const r=b(e),m=typeof a?.photoUrl=="string"&&a.photoUrl.startsWith("https://");return n.innerHTML=`
    <div class="card-header">
      ${m?`<img class="avatar" src="${a.photoUrl}" alt="" referrerpolicy="no-referrer" />`:'<div class="avatar avatar-placeholder"></div>'}
      <div class="card-header-text">
        <h2><a class="author-link" href="${r}" target="_blank" rel="noopener">${a?.name??e}</a></h2>
        <p class="affiliation">${a?.affiliation??""}</p>
      </div>
      <div class="card-actions">
        <button class="icon-btn refresh-btn" title="Refresh this author">↻</button>
        <button class="icon-btn remove-btn" title="Unfollow">✕</button>
      </div>
    </div>
    <div class="card-body">
      <p class="status-line status-${s}" title="${t?.error??""}">${E[s]??s}${s==="pending"?'<span class="spinner"></span>':""}</p>
      ${s==="error"&&t?.error?`<p class="error-detail">${t.error}</p>`:""}
      ${a?`<div class="metrics">
              <div class="metric"><span class="metric-value">${a.citationsTotal}</span><span class="metric-label">Citations</span></div>
              <div class="metric"><span class="metric-value">${a.hIndex}</span><span class="metric-label">h-index</span></div>
              <div class="metric"><span class="metric-value">${a.i10}</span><span class="metric-label">i10-index</span></div>
            </div>
            ${k(a.byYear)}`:""}
      <p class="fetched-at">Last updated: ${y(t?.fetchedAt)}</p>
    </div>
  `,n.querySelector(".refresh-btn").addEventListener("click",()=>{chrome.runtime.sendMessage({type:"REFRESH_AUTHOR",id:e})}),n.querySelector(".remove-btn").addEventListener("click",async()=>{confirm(`Unfollow "${a?.name??e}"?`)&&(await f(e),o())}),n}async function o(){const[e,t]=await Promise.all([u(),v()]);g.hidden=e.length>0,l.hidden=e.length<i,e.length>=i&&(l.textContent=`With ${e.length} authors, refreshes will take longer to complete to avoid getting blocked.`);const s=S(e,t,d.value);c.innerHTML="";for(const a of s)c.appendChild(_(a.id,t[a.id]))}$.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"REFRESH_ALL"})});d.addEventListener("change",()=>o());h(()=>o());o();
